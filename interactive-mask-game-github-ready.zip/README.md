# Marvel-Inspired Hand Gesture Interactive Game

A Python interactive visual experience developed for a school technology club workshop. The application uses a webcam and MediaPipe Hand Landmarker to detect hand gestures and control particle-based graphics inspired by Marvel characters.

## Features
- Webcam-based hand landmark detection and gesture recognition
- Interactive particle-based visual effects using Pygame and OpenGL
- Marvel-inspired shapes and effects (including Iron Man, Spider-Man, Captain America, Thor, and Hulk)

> This description is based on the source code. Add the exact gesture controls after checking the live demo.

## Requirements
- Python (tested version: **to be added**)
- Working webcam and a system supporting OpenGL
- Packages in `requirements.txt` (versions should be pinned after testing)

## Run locally

```bash
python -m venv .venv
```

Activate the environment:

- **Windows PowerShell:** `.\.venv\Scripts\Activate.ps1`
- **macOS/Linux:** `source .venv/bin/activate`

Then:

```bash
python -m pip install -r requirements.txt
python main.py
```

Allow camera access if prompted. The hand landmarker model must be present as `hand_landmarker.task` next to `main.py`.

## Demo

[Add your demo video link here.]

[Add screenshots here.]

## My role

[Describe precisely which parts you designed, coded and tested independently, and which tutorials, tools, models or AI assistants helped you.]

## Challenges and future improvements

[Add authentic technical issues and ideas for improvement, including performance and gesture accuracy.]

## Credits and permissions

- Hand detection relies on MediaPipe and a Hand Landmarker model; check the original model's redistribution/license terms before publishing its file.
- Marvel characters and trademarks belong to their respective owners. Do not upload third-party artwork unless you have permission.
- Acknowledge any borrowed code, tutorials, and assets.

## Notes

The application needs local camera and graphics support; it cannot be previewed as a static website. This repository has not yet been tested on a clean machine.
